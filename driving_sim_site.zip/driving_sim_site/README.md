# Driving Simulator Prototype — Portfolio Website

This is a simple static website (no build tools required).

## How to view locally
Option A (quick): open `index.html` in your browser.

Option B (recommended, avoids some browser restrictions):
1. In this folder, run:
   - `python3 -m http.server 8000`
2. Open:
   - http://localhost:8000

## What to edit
- `about.html` has a ready-to-fill bio + links section.
- Replace the headings/text anywhere you want.
- Swap images/videos in `assets/images` and `assets/videos`.

## Folder structure
- `index.html` — Home
- `project.html` — Project details + videos
- `development.html` — Build journey
- `about.html` — Bio and links
- `assets/` — CSS, JS, images, videos, posters

